<?php
$servername = "localhost";
$username = "root";
$password = "ateg";
$database = "practicabd";

// Crear la conexión
$conn = new mysqli($servername, $username, $password, $database);

// Verificar la conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Resto de tu código, si es necesario
?>
