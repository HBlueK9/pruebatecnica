<?php
include('config.php');

// Lógica para manejar la paginación
$registrosPorPagina = 10;
$paginaActual = isset($_GET['pagina']) ? $_GET['pagina'] : 1;
$offset = ($paginaActual - 1) * $registrosPorPagina;

// Consulta para obtener las ventas con paginación
$query = "SELECT * FROM ventas WHERE asesor_id = ? ORDER BY fecha_registro DESC LIMIT ?, ?";
$stmt = $conn->prepare($query);
$stmt->bind_param('iii', $asesorId, $offset, $registrosPorPagina);

// Asignar el id del asesor (puedes obtenerlo de la sesión, por ejemplo)
$asesorId = 1;

$stmt->execute();
$result = $stmt->get_result();
$stmt->close();

// Consulta para obtener el total de registros para la paginación
$queryTotal = "SELECT COUNT(id) as total FROM ventas WHERE asesor_id = ?";
$stmtTotal = $conn->prepare($queryTotal);
$stmtTotal->bind_param('i', $asesorId);
$stmtTotal->execute();
$resultTotal = $stmtTotal->get_result();
$totalRegistros = $resultTotal->fetch_assoc()['total'];
$stmtTotal->close();
$conn->close();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Seguimiento de Ventas</title>
    <!-- Incluir Bootstrap y jQuery -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script src="js/jquery-3.5.1.slim.min.js"></script>
    <script src="js/pagination.js"></script>

</head>
<body>

<div class="container mt-4">
    <h2>Seguimiento de Ventas</h2>

    <!-- Filtro de fecha de creación -->
    <form method="get">
        <div class="form-group">
            <label for="fecha_creacion">Filtrar por Fecha de Creación:</label>
            <input type="date" name="fecha_creacion" class="form-control">
        </div>
        <button type="submit" class="btn btn-primary">Filtrar</button>
    </form>

    <!-- Tabla de ventas -->
    <table class="table mt-4">
        <thead>
        <tr>
            <th>ID</th>
            <th>Fecha de Creación</th>
            <th>Tipo de Documento</th>
            <th>Número de Documento</th>
            <th>Nombre del Cliente</th>
            <th>Monto de Venta</th>
            <th>Acciones</th>
        </tr>
        </thead>
        <tbody>
        <?php while ($venta = $result->fetch_assoc()) : ?>
            <tr>
                <td><?php echo $venta['id']; ?></td>
                <td><?php echo $venta['fecha_registro']; ?></td>
                <td><?php echo $venta['tipo_documento']; ?></td>
                <td><?php echo $venta['numero_documento']; ?></td>
                <td><?php echo $venta['nombre_cliente']; ?></td>
                <td><?php echo $venta['monto_venta']; ?></td>
                <td><a href="#">Detalles</a></td>
            </tr>
        <?php endwhile; ?>
        </tbody>
    </table>

 
  <!-- Paginación -->
<nav aria-label="Paginación">
    <ul class="pagination" id="pagination">
        <?php
        $totalPaginas = ceil($totalRegistros / $registrosPorPagina);
        for ($i = 1; $i <= $totalPaginas; $i++) :
            ?>
            <li class="page-item <?php echo ($i == $paginaActual) ? 'active' : ''; ?>">
                <a class="page-link" href="#" data-pagina="<?php echo $i; ?>"><?php echo $i; ?></a>
            </li>
        <?php endfor; ?>
    </ul>
</nav>
</div>

</body>
</html>
