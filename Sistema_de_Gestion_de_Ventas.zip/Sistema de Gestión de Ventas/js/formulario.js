// Lógica para mostrar u ocultar campos según el tipo de documento seleccionado
document.getElementById('tipo_documento').addEventListener('change', function () {
    var tipoDocumento = this.value;
    var campoNumeroSN = document.getElementById('campo_numero_sn');
    var campoActivacionInmediata = document.getElementById('campo_activacion_inmediata');

    // Mostrar u ocultar campos según el tipo de documento
    switch (tipoDocumento) {
        case 'DNI':
            campoNumeroSN.style.display = 'block';
            campoActivacionInmediata.style.display = 'none';
            break;
        case 'C.E.':
            campoNumeroSN.style.display = 'none';
            campoActivacionInmediata.style.display = 'block';
            break;
        case 'RUC':
        case 'PASAPORTE':
            campoNumeroSN.style.display = 'none';
            campoActivacionInmediata.style.display = 'none';
            break;
    }
});

// Lógica para mostrar u ocultar campos según la activación inmediata seleccionada
document.getElementById('campo_activacion_inmediata').addEventListener('change', function () {
    var activacionInmediata = this.value;
    var campoNumeroSN = document.getElementById('campo_numero_sn');

    // Mostrar u ocultar campo número SN según la activación inmediata
    if (activacionInmediata === 'Si') {
        campoNumeroSN.style.display = 'block';
    } else {
        campoNumeroSN.style.display = 'none';
    }
});
