// pagination.js
$(document).ready(function () {
    $('#pagination').on('click', 'a', function (e) {
        e.preventDefault();
        var pagina = $(this).data('pagina');

        $.ajax({
            url: 'página_seguimiento_ventas.php',
            type: 'GET',
            data: { pagina: pagina },
            success: function (data) {
                // Actualizar el contenido de la página
                $('body').html(data);
            },
            error: function (error) {
                console.error('Error en la solicitud Ajax:', error);
            }
        });
    });
});
