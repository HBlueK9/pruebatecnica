<?php
function obtenerIdPerfil($perfil) {
    // Aquí podrías realizar una consulta a la base de datos para obtener el ID del perfil
    // En este ejemplo, retornaremos un valor fijo.
    if ($perfil === 'asesor') {
        return 2; // ID del perfil "asesor"
    }
    return 0; // Valor predeterminado o error
}
include('config.php');

// Verificar si el formulario ha sido enviado
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Validar y procesar datos del formulario
    $tipoDocumento = $_POST['tipo_documento'];
    $numeroDocumento = $_POST['numero_documento'];
    $nombreCliente = $_POST['nombre_cliente'];
    $telefono = $_POST['telefono'];
    $tipoPlan = $_POST['tipo_plan'];
    $apellidos = $_POST['apellidos'];
    $nivel1 = $_POST['nivel1'];
    $nivel2 = $_POST['nivel2'];
    $nivel3 = $_POST['nivel3'];
    $estadoVenta = 1; // Por defecto, pendiente

    // Lógica para determinar campos a mostrar u ocultar según el tipo de documento
    $activacionInmediata = isset($_POST['activacion_inmediata']) ? $_POST['activacion_inmediata'] : '';
    $mostrarNumeroSN = isset($_POST['numero_sn']) ? $_POST['numero_sn'] : '';

 // Lógica para asignar perfil_id al registrar un asesor
$perfilAsesor = obtenerIdPerfil('asesor'); // Función ficticia para obtener el ID del perfil "asesor"

// Insertar datos en la tabla ventas
$query = "INSERT INTO ventas (asesor_id, estado_venta_id, tipo_documento, numero_documento, nombre_cliente, telefono, tipo_plan, apellidos, nivel1, nivel2, nivel3, activacion_inmediata, mostrar_numero_sn) 
          VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

$stmt = $conn->prepare($query);

// Verificar si la preparación fue exitosa
if (!$stmt) {
    die('Error en la preparación de la consulta: ' . $conn->error);
}

$stmt->bind_param('iisssssssssss', $asesorId, $estadoVenta, $tipoDocumento, $numeroDocumento, $nombreCliente, $telefono, $tipoPlan, $apellidos, $nivel1, $nivel2, $nivel3, $activacionInmediata, $mostrarNumeroSN);

// Asignar el id del asesor y perfil_id (puedes obtenerlos de la sesión, por ejemplo)
$asesorId = 1;

if ($stmt->execute()) {
    echo "Venta registrada con éxito.";
} else {
    echo "Error al registrar la venta: " . $stmt->error;
}

$stmt->close();
$conn->close();
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formulario de Ventas</title>
    <script src="./js/jquery-3.5.1.slim.min.js"defer></script>
    <script src="./js/formulario.js" defer></script>
</head>
<body>

<h2>Registrar Venta</h2>
<form method="post" action="formulario_ventas.php">
    <label for="telefono">Teléfono:</label>
    <input type="tel" name="telefono" required><br>
    <label for="tipo_plan">Tipo de Plan:</label>
    <select name="tipo_plan" required>
        <option value="ILIMITADO">ILIMITADO</option>
        <option value="REGULAR">REGULAR</option>
    </select><br>
    <label for="tipo_documento">Tipo de Documento:</label>
    <select name="tipo_documento" id="tipo_documento" required>
        <option value="DNI">DNI</option>
        <option value="C.E.">C.E.</option>
        <option value="RUC">RUC</option>
        <option value="PASAPORTE">PASAPORTE</option>
    </select><br>

    <label for="numero_documento">Número de Documento:</label>
    <input type="text" name="numero_documento" required><br>

    <label for="nombre_cliente">Nombre del Cliente:</label>
    <input type="text" name="nombre_cliente" required><br>
    <label for="apellidos">Apellidos:</label>
    <input type="text" name="apellidos" required><br>


    <label for="nivel1">Nivel 1:</label>
    <select name="nivel1" required>
        <option value="Contacto Efectivo">Contacto Efectivo</option>
        <option value="Contacto No Efectivo">Contacto No Efectivo</option>
    </select><br>

    <label for="nivel2">Nivel 2:</label>
    <select name="nivel2" required>
        <option value="Venta">Venta</option>
        <option value="Agendado">Agendado</option>
        <option value="No Venta">No venta</option>
        <option value="No Llamar">No Llamar</option>
        <option value="Lamada Vicio">Lamada Vicio</option>


    </select><br>

    <label for="nivel3">Nivel 3:</label>
    <select name="nivel3" required>
        <option value="Acepta upgrade">Acepta upgrade</option>
        <option value="Renovación de equipo">Renovación de equipo</option>
        <option value="Acepta upgrade + Renovación de equipo">Acepta upgrade + Renovación de equipo</option>
        <option value="Corta llamada">Corta llamada</option>
        <option value="Corta llamada">Plan muy caro</option>
        <option value="Buzón">Buzón</option>
        <option value="Cliente no desea recibir llamadas">Cliente no desea recibir llamadas</option>
        <option value="Llamada Vicio Llamada vacía">Llamada Vicio Llamada vacía</option>

    </select><br>

    <div id="campo_numero_sn" style="display:none;">
    <label for="numero_sn">Número SN:</label>
    <input type="text" name="numero_sn">
</div>

<div id="campo_activacion_inmediata" style="display:none;">
    <label for="activacion_inmediata">Activación Inmediata:</label>
    <select name="activacion_inmediata" required>
        <option value="Si">Si</option>
        <option value="No">No</option>
    </select>
</div>

    <input type="submit" value="Registrar Venta">
</form>

</body>
</html>
